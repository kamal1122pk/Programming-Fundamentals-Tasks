// Task # 1: Generate alphabets from A to Z.  (ASCII code for A=65 and Z=90).
// PROGRAM
#include <iostream>
using namespace std;

int main() 
{
    for (int i = 65; i <= 90; i++) 
    {
        cout << char(i) << " ";
    }
    cout << endl;
    return 0;
}
