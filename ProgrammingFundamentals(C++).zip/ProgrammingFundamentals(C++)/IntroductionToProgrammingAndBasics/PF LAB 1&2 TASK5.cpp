// Task # 5 Consider the variable char character=’A’; Print the character in single quotes. Expected output : character in single quotes: ‘A’.
// PROGRAM
#include <iostream>
using namespace std;

int main() 
{
    char character = 'A';
    cout << "character in single quotes: '" << character << "'" << endl;
    return 0;
}
